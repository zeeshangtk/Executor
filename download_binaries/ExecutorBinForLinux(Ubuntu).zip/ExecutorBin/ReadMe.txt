STEPS TO RUN THIS TOOL
1)Configure the input.xml and give proper inputs to it
2)Run ./Executor Input.xml so as to give input.xml as the input
